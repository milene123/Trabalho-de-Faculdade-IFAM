package mvc.bean;

import java.util.Calendar;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

public class Categoria {

private int catid;

@NotEmpty(message="{categoria.catnome.vazia}")
@Size(min=10, max = 100, message="{categoria.catnome.limite}")

private String catnome;
//private String cattamanho;
//private float catpreco;
/*  private boolean finalizado;
private int dataNascimento;

@DateTimeFormat(pattern = "yyyy-MM-dd")
private Calendar dataFinalizacao;*/

//...

public Categoria() {}


public Categoria(int catid, String catnome) {
    this.catid = catid;
    this.catnome = catnome;

    
    }

    public int getCatid() {
        return catid;
    }

    public void setCatid(int catid ) {
        this.catid = catid;
    }

    public String getCatnome() {
        return catnome;
    }

    public void setCatnome(String catnome) {
        this.catnome = catnome;
    }

    

    
}
