package mvc.bean;

import java.util.Calendar;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

public class Cliente {
    
    private int cliid;
    
    @NotEmpty(message="{cliente.clinome.vazia}")
    @Size(min=10, max = 100, message="{cliente.clinome.limite}")

    private String clinome;
    private String clicpf;
    private String clifone;
    private String clibairro;
    private String clilogradouro;
    private String clinumcasa;
    private String clilogin;
    private String clisenha;
  /*  private boolean finalizado;
    private int dataNascimento;
    
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Calendar dataFinalizacao;*/

    //...
    
    public Cliente() {}
    

    public Cliente(int cliid, String clinome, String clicpf, String clifone, String clibairro, String clilogradouro, String clinumcasa, String clilogin, String clisenha ) {
        this.cliid = cliid;
        this.clinome = clinome;
        this.clicpf= clicpf;
        this.clifone = clifone;
        this.clibairro = clibairro;
        this.clilogradouro = clilogradouro;
        this.clinumcasa = clinumcasa;
        this.clilogin = clilogin;
        this.clisenha = clisenha;
    }

    public int getCliid() {
        return cliid;
    }

    public String getClinome() {
        return clinome;
    }

    public String getClicpf() {
        return clicpf;
    }

    public String getClifone() {
        return clifone;
    }

    public String getClibairro() {
        return clibairro;
    }

    public String getClilogradouro() {
        return clilogradouro;
    }

    public String getClinumcasa() {
        return clinumcasa;
    }

    public String getClilogin() {
        return clilogin;
    }

    public String getClisenha() {
        return clisenha;
    }

    public void setCliid(int cliid) {
        this.cliid = cliid;
    }

    public void setClinome(String clinome) {
        this.clinome = clinome;
    }

    public void setClicpf(String clicpf) {
        this.clicpf = clicpf;
    }

    public void setClifone(String clifone) {
        this.clifone = clifone;
    }

    public void setClibairro(String clibairro) {
        this.clibairro = clibairro;
    }

    public void setClilogradouro(String clilogradouro) {
        this.clilogradouro = clilogradouro;
    }

    public void setClinumcasa(String clinumcasa) {
        this.clinumcasa = clinumcasa;
    }

    public void setClilogin(String clilogin) {
        this.clilogin = clilogin;
    }

    public void setClisenha(String clisenha) {
        this.clisenha = clisenha;
    }
    

}
