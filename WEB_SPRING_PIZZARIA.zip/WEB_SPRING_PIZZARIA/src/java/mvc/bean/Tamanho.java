package mvc.bean;

import java.util.Calendar;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

public class Tamanho {

private int tamid;

//@NotEmpty(message="{categoria.catnome.vazia}")
//@Size(min=10, max = 100, message="{categoria.catnome.limite}")

private String tamnome;

/*  private boolean finalizado;
private int dataNascimento;

@DateTimeFormat(pattern = "yyyy-MM-dd")
private Calendar dataFinalizacao;*/

//...

public Tamanho() {}


public Tamanho(int tamid, String tamnome) {
    this.tamid = tamid;
    this.tamnome = tamnome;

    
    }

    public int getTamid() {
        return tamid;
    }

    public void setTamid(int tamid ) {
        this.tamid = tamid;
    }

    public String getTamnome() {
        return tamnome;
    }

    public void setTamnome(String tamnome) {
        this.tamnome = tamnome;
    }

    

    
}
