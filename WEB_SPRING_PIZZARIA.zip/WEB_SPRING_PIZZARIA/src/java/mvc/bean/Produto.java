/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.bean;

import java.util.Calendar;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

public class Produto{
    
    private int proid;
    
    private String pronome;
    private String prodetalhe;
    private int protamid;
    private float propreco;
    private int procatid;
    private String proimagem;

    public Produto() {
    }

    public int getProid() {
        return proid;
    }

    public void setProid(int proid) {
        this.proid = proid;
    }

    public String getPronome() {
        return pronome;
    }

    public void setPronome(String pronome) {
        this.pronome = pronome;
    }

    public String getProdetalhe() {
        return prodetalhe;
    }

    public void setProdetalhe(String prodetalhe) {
        this.prodetalhe = prodetalhe;
    }

    public int getProtamid() {
        return protamid;
    }

    public void setProtamid(int protamid) {
        this.protamid = protamid;
    }

    public float getPropreco() {
        return propreco;
    }

    public void setPropreco(float propreco) {
        this.propreco = propreco;
    }

    public int getProcatid() {
        return procatid;
    }

    public void setProcatid(int procatid) {
        this.procatid = procatid;
    }

    public String getProimagem() {
        return proimagem;
    }

    public void setProimagem(String proimagem) {
        this.proimagem = proimagem;
    }

    
}