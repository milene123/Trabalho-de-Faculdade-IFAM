/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.bean;

import java.util.Calendar;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

/**
 *
 * @author Milene
 */
public class Curriculo {
    private int curid;
    
    @NotEmpty(message="{curriculo.curnome.vazia}")
    @Size(min=10, max = 100, message="{curriculo.curnome.limite}")

    private String curnome;
    private int curcpf;
    private int currg;
    private String curemail;
    private int curtelefone;
    private char cursexo;
    private int curdatanasc;
    
    /*private boolean finalizado;
    
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Calendar dataFinalizado;*/

    //...
    
    public Curriculo() {}

    public int getCurid() {
        return curid;
    }

    public void setCurid(int curid) {
        this.curid = curid;
    }

    public String getCurnome() {
        return curnome;
    }

    public void setCurnome(String curnome) {
        this.curnome = curnome;
    }
    public int getCurcpf() {
        return curcpf;
    }

    public void setCurcpf(int curcpf) {
        this.curcpf = curcpf;
    }
    public int getCurrg() {
        return currg;
    }

    public void setCurrg(int currg) {
        this.currg = currg;
    }
    public String getCuremail() {
        return curemail;
    }

    public void setCuremail(String curemail) {
        this.curemail = curemail;
    }
    public int getCurtelefone() {
        return curtelefone;
    }

    public void setCurtelefone(int curtelefone) {
        this.curtelefone = curtelefone;
    }
    public int getCurdatanasc() {
        return curdatanasc;
    }

    public void setDataNascimento(int curdatanasc) {
        this.curdatanasc = curdatanasc;
    }
    
    
    public char getCursexo() {
        return cursexo;
    }

    public void setSexo(char cursexo) {
        this.cursexo = cursexo;
    }
    
    /*public boolean isFinalizado() {
        return finalizado;
    }

    public void setFinalizado(boolean finalizado) {
        this.finalizado = finalizado;
    }

    public Calendar getDataFinalizado() {
        return dataFinalizado;
    }

    public void setDataFinalizado(Calendar dataNascimento) {
        this.dataFinalizado = dataFinalizado;
    }*/
    
    
}
