/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.sql.DataSource;
import mvc.bean.Categoria;
import mvc.bean.Tamanho;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class TamanhoDAO {
    
    private final Connection connection;
    
    @Autowired
    public TamanhoDAO(DataSource dataSource){
        try {
            this.connection = dataSource.getConnection();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }
    
    public boolean adicionaTamanho (Tamanho tamanho){
       String sql = "insert into tamanho (tamnome) values (?)";
       try ( 
        // prepared statement para inserção
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        // seta os valores
        stmt.setString(1,tamanho.getTamnome());
        
        // executa
        stmt.execute();
       } catch (SQLException e) {
         e.printStackTrace();
       }
       return true;
    }    
    
    public List<Tamanho> listarTamanhos(){
       List<Tamanho> listarTamanhos = new ArrayList<Tamanho>();
       String sql = "select * from tamanho order by tamnome";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
           Tamanho tamanho = new Tamanho();
           tamanho.setTamid(rs.getInt("tamid"));
           tamanho.setTamnome(rs.getString("tamnome"));
           //categoria.setCattamanho(rs.getString("cattamanho"));
           //categoria.setCatpreco(rs.getFloat("catpreco"));
   /*        categoria.setFinalizado(rs.getBoolean("finalizado"));
           //montando data
           Calendar data = Calendar.getInstance();
           if(rs.getDate("dataFinalizacao") != null)
           {
               data.setTime(rs.getDate("dataFinalizacao"));
               categoria.setDataFinalizacao(data);
           }*/        
           listarTamanhos.add(tamanho);           
        }
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
       return listarTamanhos;
    }
    
    public Tamanho buscarTamanhoPorId(Integer tamid){
       String sql = "select * from tamanho where tamid = ? ";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setInt(1,tamid);
        ResultSet rs = stmt.executeQuery();
        Tamanho tamanho = new Tamanho();
        if(rs.next()) {
           tamanho.setTamid(rs.getInt("tamid"));
           tamanho.setTamnome(rs.getString("tamnome"));
           //categoria.setCattamanho(rs.getString("cattamanho"));
           //categoria.setCatpreco(rs.getFloat("catpreco"));
        /*   categoria.setFinalizado(rs.getBoolean("finalizado"));
           //montando data
           Calendar data = Calendar.getInstance();
           if(rs.getDate("dataFinalizacao") != null)
           {
               data.setTime(rs.getDate("dataFinalizacao"));
               System.out.println("data");
               categoria.setDataFinalizacao(data);
           }  */              
        }
        return tamanho;
        
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
    }
    
    public boolean removerTamanho(Integer tamid){
       String sql = "delete from tamanho where tamid = ? ";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setInt(1,tamid);
        stmt.execute();
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
       return true;
    }
    
    public boolean alteraTamanho(Tamanho tamanho){
       String sql = "update categoria set catnome = ?,"
                  + " where catid = ? ";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setString(1,tamanho.getTamnome());
        //stmt.setString(2,categoria.getCattamanho());
        //stmt.setFloat(3,categoria.getCatpreco());
   /*     stmt.setBoolean(4,categoria.isFinalizado());
        if(categoria.getDataFinalizacao() != null){
            stmt.setDate(3, new Date(categoria.getDataFinalizacao().getTimeInMillis()));
        }else{
            stmt.setNull(3, java.sql.Types.DATE);
        }*/
        stmt.setInt(4,tamanho.getTamid());
        stmt.execute();
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
       return true;
    }
    
    /*public boolean finalizarCategoria(int id){
       String sql = " update categoria set finalizado=true, "
               +    " dataFinalizacao=now() where idcategoria = ? ";
       try { 
        PreparedStatement stmt = connection.prepareStatement(sql);
        stmt.setInt(1, id);
        stmt.execute();
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
       return true;
    }*/
    
    
}
