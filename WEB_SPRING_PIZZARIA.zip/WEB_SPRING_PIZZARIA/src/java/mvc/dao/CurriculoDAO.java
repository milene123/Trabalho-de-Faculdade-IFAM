/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.sql.DataSource;
import mvc.bean.Categoria;
import mvc.bean.Curriculo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Milene
 */
@Repository
public class CurriculoDAO {
    private final Connection connection;
    
    @Autowired
    public CurriculoDAO(DataSource dataSource){
        try {
            this.connection = dataSource.getConnection();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }
    
    public boolean adicionaCurriculo(Curriculo curriculo){
       String sql = "insert into curriculo (curnome,curcpf,currg,curdatanas,curemail,curtelefone,cursexo) values (?,?,?,?,?,?,?)";
       try ( 
        // prepared statement para inserção
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        // seta os valores
        stmt.setString(1,curriculo.getCurnome());
        stmt.setInt(2,curriculo.getCurrg());
        stmt.setInt(3,curriculo.getCurdatanasc());
        stmt.setString(4,curriculo.getCuremail());
        stmt.setInt(5,curriculo.getCurtelefone());
        stmt.setInt(6,curriculo.getCursexo());
        // executa
        stmt.execute();
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
       return true;
    }    
    
    public List<Curriculo> listarCurriculos(){
       List<Curriculo> listarCurriculos = new ArrayList<Curriculo>();
       String sql = "select * from curriculo order by curnome";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
           Curriculo curriculo = new Curriculo();
           curriculo.setCurid(rs.getInt("curid"));
           curriculo.setCurnome(rs.getString("curnome"));
           curriculo.setCurcpf(rs.getInt("curcpf"));
           curriculo.setCurrg(rs.getInt("currg"));
           curriculo.setCuremail(rs.getString("curemail"));
           curriculo.setCurtelefone(rs.getInt("curtelefone"));
           //curriculo.setSexo(rs.getString("sexo"));
           //curriculo.setFinalizado(rs.getBoolean("finalizado"));
           //montando data
           /*Calendar data = Calendar.getInstance();
           if(rs.getDate("dataFinalizacao") != null)
           {
               data.setTime(rs.getDate("dataFinalizacao"));
               curriculo.setDataFinalizado(data);
           }        */
           listarCurriculos.add(curriculo);           
        }
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
       return listarCurriculos;
    }
    
    public Curriculo buscarCurriculoPorId(Integer id){
       String sql = "select * from curriculo where curid = ? ";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setInt(1,id);
        ResultSet rs = stmt.executeQuery();
        Curriculo curriculo = new Curriculo();
        if(rs.next()) {
           curriculo.setCurid(rs.getInt("curid"));
           curriculo.setCurnome(rs.getString("curnome"));
           curriculo.setCurcpf(rs.getInt("curcpf"));
           curriculo.setCurrg(rs.getInt("currg"));
           curriculo.setCuremail(rs.getString("curemail"));
           curriculo.setCurtelefone(rs.getInt("curtelefone"));
           
           //curriculo.setFinalizado(rs.getBoolean("finalizado"));
           //montando data
           /*Calendar data = Calendar.getInstance();
           if(rs.getDate("dataFinalizacao") != null)
           {
               data.setTime(rs.getDate("dataFinalizacao"));
               System.out.println("data");
               curriculo.setDataFinalizado(data);
           }   */              
        }
        return curriculo;
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
    }
    
    
    
    
    /*public boolean finalizarCurriculo(int id){
       String sql = " update curriculo set finalizado=true, "
               +    " dataNascimento=now() where id = ? ";
       try { 
        PreparedStatement stmt = connection.prepareStatement(sql);
        stmt.setInt(1, id);
        stmt.execute();
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
       return true;
    }*/
    
    
}

