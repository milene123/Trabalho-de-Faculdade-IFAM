/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.sql.DataSource;
import mvc.bean.Produto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ProdutoDAO {
    
    private final Connection connection;
    
    @Autowired
    public ProdutoDAO(DataSource dataSource){
        try {
            this.connection = dataSource.getConnection();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }
    
    public boolean adicionaProduto(Produto produto){
       String sql = "insert into produto (pronome, prodetalhe, protamid, propreco, procatid, proimagem) values (?,?,?,?,?,?)";
       try ( 
        // prepared statement para inserção
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        // seta os valores
        stmt.setString(1,produto.getPronome());
        stmt.setString(2,produto.getProdetalhe());
        stmt.setInt(3,produto.getProtamid());
        stmt.setFloat(4,produto.getPropreco());
        stmt.setInt(5, produto.getProcatid());
        stmt.setString(6, produto.getProimagem());
       
        
        // executa
        stmt.execute();
       } catch (SQLException e) {
         e.printStackTrace();
       }
       return true;
    }    
    
    public List<Produto> listarProdutos(){
       List<Produto> listarProdutos = new ArrayList<Produto>();
       String sql = "select * from produto order by pronome";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
           Produto produto = new Produto();
           produto.setProid(rs.getInt("proid"));
           produto.setPronome(rs.getString("pronome"));
           produto.setProdetalhe(rs.getString("prodetalhe"));
           produto.setProtamid(rs.getInt("protamid"));
           produto.setPropreco(rs.getFloat("propreco"));
           produto.setProcatid(rs.getInt("procatid"));
           
   /*        categoria.setFinalizado(rs.getBoolean("finalizado"));
           //montando data
           Calendar data = Calendar.getInstance();
           if(rs.getDate("dataFinalizacao") != null)
           {
               data.setTime(rs.getDate("dataFinalizacao"));
               categoria.setDataFinalizacao(data);
           }*/        
           listarProdutos.add(produto);           
        }
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
       return listarProdutos;
    }
    
    public Produto buscarProdutoPorId(Integer proid){
       String sql = "select * from produto where proid = ? ";
        //System.out.println("**************"+sql+"  "+proid);
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setInt(1,proid);
        ResultSet rs = stmt.executeQuery();
        Produto produto = new Produto();
        if(rs.next()) {
           produto.setProid(rs.getInt("proid"));
           produto.setPronome(rs.getString("pronome"));
           produto.setProdetalhe(rs.getString("prodetalhe"));
           produto.setProtamid(rs.getInt("protamid"));
           produto.setPropreco(rs.getFloat("propreco"));
           produto.setProcatid(rs.getInt("procatid"));
           
        /*   categoria.setFinalizado(rs.getBoolean("finalizado"));
           //montando data
           Calendar data = Calendar.getInstance();
           if(rs.getDate("dataFinalizacao") != null)
           {
               data.setTime(rs.getDate("dataFinalizacao"));
               System.out.println("data");
               categoria.setDataFinalizacao(data);
           }  */              
        }
        return produto;
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
    }
    
    public boolean removerProduto(Integer proid){
       String sql = "delete from produto where proid = ? ";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setInt(1,proid);
        stmt.execute();
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
       return true;
    }
    
    public boolean alteraProduto(Produto produto){
       String sql = "update produto set pronome = ?,"
                  + " prodetalhe=?, protamid=?, propreco=? where catid = ? ";
       try ( 
        PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setString(1,produto.getPronome());
        stmt.setString(2,produto.getProdetalhe());
        stmt.setInt(3,produto.getProtamid());
        stmt.setFloat(4,produto.getPropreco());
        stmt.setInt(5,produto.getProcatid());
        
   /*     stmt.setBoolean(4,categoria.isFinalizado());
        if(categoria.getDataFinalizacao() != null){
            stmt.setDate(3, new Date(categoria.getDataFinalizacao().getTimeInMillis()));
        }else{
            stmt.setNull(3, java.sql.Types.DATE);
        }*/
        stmt.setInt(4,produto.getProid());
        stmt.execute();
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
       return true;
    }
    
    /*public boolean finalizarCategoria(int id){
       String sql = " update categoria set finalizado=true, "
               +    " dataFinalizacao=now() where idcategoria = ? ";
       try { 
        PreparedStatement stmt = connection.prepareStatement(sql);
        stmt.setInt(1, id);
        stmt.execute();
       } catch (SQLException e) {
         throw new RuntimeException(e);
       }
       return true;
    }*/
    
    
}

