/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.controller;

import javax.validation.Valid;
import mvc.bean.Categoria;
import mvc.bean.Curriculo;
import mvc.dao.CategoriaDAO;
import mvc.dao.CurriculoDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author Milene
 */
@Controller
public class CurriculoController {
    private final CurriculoDAO dao;
    
    @Autowired
    public CurriculoController(CurriculoDAO dao) {
        this.dao = dao;
    }
    
    @RequestMapping("/formAdicionaCurriculo")
    public String form(){
        return "/curriculo/formularioAdicionaCurriculo";
    }
    
    @RequestMapping("/adicionaCurriculo")
    public String adiciona(Curriculo curriculo){

        //if(result.hasErrors()){
            //return "curriculo/formularioAdicionaCurriculo";
        //}

        dao.adicionaCurriculo(curriculo);
        return "curriculo/categoria-adicionada";
    }
    
    @RequestMapping("/listarCurriculo")
    public String lista(Model model){
        model.addAttribute("listarCurriculo", dao.listarCurriculos());
        return "curriculo/listagem-curriculos";
    }
    
    
    
    @RequestMapping("/exibeCurriculo")
    public String exibe(Integer id, Model model){
        model.addAttribute("categoria", dao.buscarCurriculoPorId(id));
        return "curriculo/exibe-curriculo";
    }
    
    
    
    /*@RequestMapping("/finalizaCurriculo")
    public String finaliza(Integer id, Model model) {
        dao.finalizarCurriculo(id);
        model.addAttribute("categoria", dao.buscarCurriculoPorId(id));
        return "curriculo/dataNascimento";
    }*/
    
    
}
