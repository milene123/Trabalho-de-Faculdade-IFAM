/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.controller;

import javax.validation.Valid;
import mvc.bean.Categoria;
import mvc.bean.Cliente;
import mvc.dao.CategoriaDAO;
import mvc.dao.ClienteDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ClienteController {
    
    private final ClienteDAO dao;
    
    @Autowired
    public ClienteController(ClienteDAO dao) {
        this.dao = dao;
    }
    
    @RequestMapping("/formAdicionaCliente")
    public String form(){
        return "cliente/formularioAdicionaCliente";
    }
    
    @RequestMapping("/adicionaCliente")
    public String adiciona(Cliente cliente){

       //System.out.println("oi2222"+ categoria.getCatnome());
        /*if(result.hasErrors()){
            System.out.println(result.hasErrors());
            return "categoria/formularioAdicionaCategoria";
        }*/

        dao.adicionaCliente(cliente);
        //return "categoria/formularioAdicionaCategoria";
        return "cliente/cliente-adicionado";
    }
    
    @RequestMapping("/listClientes")
    public String lista(Model model){
        model.addAttribute("listarClientes", dao.listarClientes());
        //System.out.println(dao.listarCategorias());
        return "cliente/listagem-cliente";
    }
    
    @RequestMapping("/removeCliente")
    public String remove(Integer cliid){
        dao.removerCliente(cliid);
        return "redirect:/listClientes";
    }
    
    @RequestMapping("/exibeCliente")
    public String exibe(Integer cliid, Model model){
        model.addAttribute("cliente", dao.buscarClientePorId(cliid));
        return "cliente/exibe-cliente";
    }
    
    @RequestMapping("/alteraCliente")
    public String altera(Cliente cliente){
       /*if(result.hasErrors()){
            return "categoria/exibe-categoria";
       }*/
       dao.alteraCliente(cliente);
       return "redirect:/listClientes";
    }
    
    /*@RequestMapping("/categoria/finalizaCategoria")
    public String finaliza(Integer id, Model model) {
        dao.finalizarCategoria(id);
        model.addAttribute("categoria", dao.buscarCategoriaPorId(id));
        return "/dataFinalizada";
    }*/
    
}



