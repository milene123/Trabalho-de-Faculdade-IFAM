/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.controller;

import javax.validation.Valid;
import mvc.bean.Categoria;
import mvc.bean.Tamanho;
import mvc.dao.CategoriaDAO;
import mvc.dao.TamanhoDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TamanhoController {
    
    private final TamanhoDAO dao;
    
    @Autowired
    public TamanhoController(TamanhoDAO dao) {
        this.dao = dao;
    }
    
    @RequestMapping("/formAdicionaTamanho")
    public String form(){
        return "tamanho/formularioAdicionaTamanho";
    }
    
    @RequestMapping("/adicionaTamanho")
    public String adiciona(Tamanho tamanho){

       //System.out.println("oi2222"+ categoria.getCatnome());
        /*if(result.hasErrors()){
            System.out.println(result.hasErrors());
            return "categoria/formularioAdicionaCategoria";
        }*/

        dao.adicionaTamanho(tamanho);
        //return "categoria/formularioAdicionaCategoria";
        return "tamanho/tamanho-adicionado";
    }
    
    @RequestMapping("/listTamanhos")
    public String lista(Model model){
        model.addAttribute("listarTamanhos", dao.listarTamanhos());
        //System.out.println(dao.listarCategorias());
        return "tamanho/listagem-tamanhos";
    }
    
    @RequestMapping("/removeTamanho")
    public String remove(Integer tamid){
        dao.removerTamanho(tamid);
        return "redirect:/listTamanhos";
    }
    /*@RequestMapping("/remCategoria")
    public String exiberemocao(Integer id){
        dao.removerCategoria(id);
        return "categoria/categoria-excluida";
    }*/
    
    @RequestMapping("/exibeTamanho")
    public String exibe(Integer tamid, Model model){
        model.addAttribute("tamanho", dao.buscarTamanhoPorId(tamid));
        return "tamanho/exibe-tamanho";
    }
    
    @RequestMapping("/alteraTamanho")
    public String altera(Tamanho tamanho){
       /*if(result.hasErrors()){
            return "categoria/exibe-categoria";
       }*/
       dao.alteraTamanho(tamanho);
       return "redirect:/listCategorias";
       //return "categoria/listagem-categorias";
    }
    
    /*@RequestMapping("/categoria/finalizaCategoria")
    public String finaliza(Integer id, Model model) {
        dao.finalizarCategoria(id);
        model.addAttribute("categoria", dao.buscarCategoriaPorId(id));
        return "/dataFinalizada";
    }*/
    
}



