/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.controller;

import javax.validation.Valid;
import mvc.bean.Categoria;
import mvc.dao.CategoriaDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CategoriaController {
    
    private final CategoriaDAO dao;
    
    @Autowired
    public CategoriaController(CategoriaDAO dao) {
        this.dao = dao;
    }
    
    @RequestMapping("/formAdicionaCategoria")
    public String form(){
        return "categoria/formularioAdicionaCategoria";
    }
    
    @RequestMapping("/adicionaCategoria")
    public String adiciona(Categoria categoria){

       //System.out.println("oi2222"+ categoria.getCatnome());
        /*if(result.hasErrors()){
            System.out.println(result.hasErrors());
            return "categoria/formularioAdicionaCategoria";
        }*/

        dao.adicionaCategoria(categoria);
        //return "categoria/formularioAdicionaCategoria";
        return "categoria/categoria-adicionada";
    }
    
    @RequestMapping("/listCategorias")
    public String lista(Model model){
        model.addAttribute("listarCategorias", dao.listarCategorias());
        //System.out.println(dao.listarCategorias());
        return "categoria/listagem-categorias";
    }
    
    @RequestMapping("/removeCategoria")
    public String remove(Integer catid){
        dao.removerCategoria(catid);
        return "redirect:/listCategorias";
    }
    /*@RequestMapping("/remCategoria")
    public String exiberemocao(Integer id){
        dao.removerCategoria(id);
        return "categoria/categoria-excluida";
    }*/
    
    @RequestMapping("/exibeCategoria")
    public String exibe(Integer catid, Model model){
        model.addAttribute("categoria", dao.buscarCategoriaPorId(catid));
        return "categoria/exibe-categoria";
    }
    
    @RequestMapping("/alteraCategoria")
    public String altera(Categoria categoria){
       /*if(result.hasErrors()){
            return "categoria/exibe-categoria";
       }*/
       dao.alteraCategoria(categoria);
       return "redirect:/listCategorias";
       //return "categoria/listagem-categorias";
    }
    
    /*@RequestMapping("/categoria/finalizaCategoria")
    public String finaliza(Integer id, Model model) {
        dao.finalizarCategoria(id);
        model.addAttribute("categoria", dao.buscarCategoriaPorId(id));
        return "/dataFinalizada";
    }*/
    
}



