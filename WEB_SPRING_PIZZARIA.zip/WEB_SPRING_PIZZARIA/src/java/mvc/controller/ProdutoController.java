/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import mvc.bean.Produto;
import mvc.dao.CategoriaDAO;
import mvc.dao.ProdutoDAO;
import mvc.dao.TamanhoDAO;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class ProdutoController {
    
    private final ProdutoDAO dao;
    private final CategoriaDAO daoCategoria;
    private final TamanhoDAO daoTamanho;
    //private Integer proid;
    
    @Autowired
    public ProdutoController(ProdutoDAO dao, CategoriaDAO daoCategoria, TamanhoDAO daoTamanho) {
        this.dao = dao;
        this.daoCategoria = daoCategoria;
        this.daoTamanho = daoTamanho;
    }
    
    @RequestMapping("/formAdicionaProduto")
    public String form(Model model){
        model.addAttribute("categorias", daoCategoria.listarCategorias());
        model.addAttribute("tamanhos", daoTamanho.listarTamanhos());
        return "produto/formularioAdicionaProduto";
    }
    
    @RequestMapping(value="/adicionaProduto", method = RequestMethod.POST)
    public String adiciona(HttpServletRequest request) throws FileUploadException{
        List<String> dados = new ArrayList<>();
        
        //request.getParameter("")

        String path = request.getServletContext().getRealPath("/uploads");
        
        path = path.substring(0, path.indexOf("\\build"));
        
        path = path+"\\web\\uploads";
        
        //String path = "C:\\Users\\Ana Toledano\\Desktop\\WEB_PROJETO\\Trabalho Web\\WEB_SPRING_PIZZARIA\\web\\uploads";
       
        DiskFileItemFactory dfif = new DiskFileItemFactory();
        ServletFileUpload uploader = new ServletFileUpload(dfif);
        
        try {
            List<FileItem> lst = uploader.parseRequest(request);
            for (FileItem fileItem : lst) {
                if (fileItem.isFormField() == false){
                    fileItem.write(new File(path+"/"+fileItem.getName()));
                    path= "/uploads/"+fileItem.getName();
                    
                } else {
                    String value = fileItem.getString();
                    dados.add(value);
                }
            }
        } catch (Exception e) {    
            e.printStackTrace();
            return "index";
        }
        
        
        
        Produto produto = new Produto();
        produto.setPronome(dados.get(0));
        produto.setProdetalhe(dados.get(1));
        produto.setProtamid(Integer.valueOf(dados.get(2)));
        produto.setPropreco(Float.valueOf(dados.get(3)));
        produto.setProcatid(Integer.valueOf(dados.get(4)));
        produto.setProimagem(path);
     
        
       if(dao.adicionaProduto(produto))
            return "produto/produto-adicionado";
       else{
           return "index";
       }
        
        
    }
    
    @RequestMapping("/listProdutos")
    public String lista(Model model){
        model.addAttribute("listarProdutos", dao.listarProdutos());
        //System.out.println(dao.listarCategorias());
        return "produto/listagem-produto";
    }
    
    @RequestMapping("/removeProduto")
    public String remove(Integer proid){
        dao.removerProduto(proid);
        return "redirect:/listProdutos";
    }
    /*@RequestMapping("/remCategoria")
    public String exiberemocao(Integer id){
        dao.removerCategoria(id);
        return "categoria/categoria-excluida";
    }*/
    
    @RequestMapping("/exibeProduto")
    public String exibe(Integer proid, Model model){
        model.addAttribute("produto", dao.buscarProdutoPorId(proid));
        return "produto/exibe-produto";
    }
    
    @RequestMapping("/alteraProduto")
    public String altera(Produto produto){
       /*if(result.hasErrors()){
            return "categoria/exibe-categoria";
       }*/
       dao.alteraProduto(produto);
       return "redirect:/listProdutos";
       //return "categoria/listagem-categorias";
    }
    
    /*@RequestMapping("/categoria/finalizaCategoria")
    public String finaliza(Integer id, Model model) {
        dao.finalizarCategoria(id);
        model.addAttribute("categoria", dao.buscarCategoriaPorId(id));
        return "/dataFinalizada";
    }*/
    
}



