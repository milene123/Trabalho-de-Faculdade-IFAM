function finalizaAgora(id) {
    $.post("finalizaCurriculo", {'id' : id}, function(dadosDeResposta) {
        // selecionando o elemento html através da
        // ID e alterando o HTML dele
        $("#curriculo_"+id).html("Finalizado");
        $("#curriculo_data_"+id).html(dadosDeResposta);
    });
}

