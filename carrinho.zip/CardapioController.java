package mvc.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import javax.servlet.http.HttpSession;
import mvc.bean.Produto;
import mvc.dao.ProdutoTamanhoDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import mvc.bean.ItemVenda;
import mvc.bean.Venda;
import mvc.dao.CategoriaDAO;
import mvc.dao.CompraDAO;
import mvc.dao.ProdutoDAO;
/**
 *
 * @author Erick
 */
@Controller
public class CardapioController {
    private final ProdutoDAO produtoDAO;
    private final ProdutoTamanhoDAO produtoTamanhoDAO;
    private final CompraDAO compraDAO;
    private final CategoriaDAO categoriaDAO;
    private final List<ItemVenda> itensVenda = new ArrayList<>();
    
    @Autowired
    public CardapioController(ProdutoDAO produtoDAO, ProdutoTamanhoDAO produtoTamanhoDAO, CompraDAO compraDAO, CategoriaDAO categoriaDAO) {
        this.produtoDAO = produtoDAO;
        this.produtoTamanhoDAO = produtoTamanhoDAO;
        this.compraDAO = compraDAO;
        this.categoriaDAO = categoriaDAO;
    }
    
    @RequestMapping("/exibeCardapio")
    public String formularioCadastroCategoria(Model model){
        model.addAttribute("produtos", produtoDAO.produtos());
        model.addAttribute("tamanhos", produtoDAO.tamanhos());
        model.addAttribute("produtosTamanhos", produtoTamanhoDAO.produtosTamanhos());
        
        return "/produto/cardapio";
    }
    
    @RequestMapping("/modificaQuantidade")
    public void modificaQuantidade(int posicao, int quantidade, HttpServletResponse response){
        //System.out.println("posicao " + posicao + "quantiade " + quantidade);
        itensVenda.get(posicao).setItvqtde(quantidade);
        
        System.out.println(itensVenda);
        
        response.setStatus(200);
    }
    
    @RequestMapping("/finalizaCompra")
    public String finalizaCompra(){
        float valorTotal = 0;
        float valor = 0;
        
        for (ItemVenda itemVenda : itensVenda) {
            valor = compraDAO.pesquisaValor(itemVenda.getItvprtproid(), itemVenda.getItvprttamid());
            valor = valor*itemVenda.getItvqtde();
            valorTotal = valorTotal + valor;
        }
        Venda venda  = new Venda();
        venda.setVendata(Calendar.getInstance());
        venda.setVentotal(valorTotal);
        venda.setVenusuid(1);
        
        if(compraDAO.adicionaVenda(venda)){
            for (ItemVenda itemVenda : itensVenda) {
                compraDAO.finalizaCompra(itemVenda);
            }
            return "alerta/mensagemConfirmacao";
        }else{
            return "alerta/mensagemErro";
        }        
    }
    
    @RequestMapping("exibeCarrinho")
    public String exibeCarrinho(HttpSession session, Model model){
        session.setAttribute("itensVenda", itensVenda);
        model.addAttribute("produtos", produtoDAO.produtos());
        model.addAttribute("produtosTamanhos", produtoTamanhoDAO.produtosTamanhos());
        model.addAttribute("categorias", categoriaDAO.categorias());
                
        return "carrinho/carrinhoCompras";
    }
    
    @RequestMapping("/carrinhoCompras")
    public void carrinhoCompras(int proid, int radio, HttpServletResponse response, 
            Model model, HttpSession session) throws IOException{
        //System.out.println("********"+value.getParameter("radio"));
        
        ItemVenda itemVenda = new ItemVenda();
        //itemVenda.setItvprtproid(Integer.parseInt(request.getParameter("proid")));
        //itemVenda.setItvprttamid(Integer.parseInt(request.getParameter("radio")));
        //itemVenda.setItvqtde(1);
        
        itemVenda.setItvprtproid(proid);
        itemVenda.setItvprttamid(radio);
        itemVenda.setItvqtde(1);
               
        //itensVenda.add(itemVenda);
        session.setAttribute("itensVenda", itensVenda);
        model.addAttribute("produtos", produtoDAO.produtos());
        model.addAttribute("produtosTamanhos", produtoTamanhoDAO.produtosTamanhos());
        model.addAttribute("categorias", categoriaDAO.categorias());
        model.addAttribute("tamanhos", produtoDAO.tamanhos());
        response.setStatus(200);
        
        if(compraDAO.verificaItemAdicionado(proid, radio, itensVenda)){
            response.getWriter().write("1");
        }
        else{
            response.getWriter().write("2");
            itensVenda.add(itemVenda);
        }
    }
    
    @RequestMapping("/excluiItem")
    public void excluiItem(int id, HttpServletResponse response){
        //produtoDAO.excluiProduto(id);
        itensVenda.remove(id);
        response.setStatus(200);
    }
}
